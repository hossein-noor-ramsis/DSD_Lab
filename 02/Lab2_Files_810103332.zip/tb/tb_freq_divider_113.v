`timescale 1ns / 1ns

module tb_freq_divider_113;
  wire clk_ring;
  reg  enable;
  reg  preset;
  wire rco_out;

  ring_oscillator #(
      .NUM_INVERTERS(3),
      .DELAY(107.5)
  ) ring_osc (
      .enable (1'b1),
      .osc_out(clk_ring)
  );

  freq_divider_113 DUT (
      .CLK(clk_ring),
      .ENABLE(enable),
      .PRESET(preset),
      .RCO_OUT(rco_out)
  );

  initial begin
    enable = 1;  // Disable counter
    preset = 0;  // Load mode
    #5000;

    preset = 1;  // Load initial value 143
    #5000;

    enable = 0;
    #1000000;  // Run long enough
    $stop;
  end
endmodule
