


INPUT clkPB;
INPUT rst;
INPUT clk;
INPUT serIn;
OUTPUT SerOut;
OUTPUT SerOutValid;
OUTPUT Seg[0];
OUTPUT Seg[1];
OUTPUT Seg[2];
OUTPUT Seg[3];
OUTPUT Seg[4];
OUTPUT Seg[5];
OUTPUT Seg[6];
OUTPUT count_out[0];
OUTPUT count_out[1];
OUTPUT count_out[2];
OUTPUT count_out[3];

/*Arc definitions start here*/
pos_clkPB__clk__setup:		SETUP (POSEDGE) clkPB clk ;
pos_rst__clk__setup:		SETUP (POSEDGE) rst clk ;
pos_serIn__clk__setup:		SETUP (POSEDGE) serIn clk ;
pos_clkPB__clk__hold:		HOLD (POSEDGE) clkPB clk ;
pos_rst__clk__hold:		HOLD (POSEDGE) rst clk ;
pos_serIn__clk__hold:		HOLD (POSEDGE) serIn clk ;
pos_clk__Seg[0]__delay:		DELAY (POSEDGE) clk Seg[0] ;
pos_clk__Seg[1]__delay:		DELAY (POSEDGE) clk Seg[1] ;
pos_clk__Seg[2]__delay:		DELAY (POSEDGE) clk Seg[2] ;
pos_clk__Seg[3]__delay:		DELAY (POSEDGE) clk Seg[3] ;
pos_clk__Seg[4]__delay:		DELAY (POSEDGE) clk Seg[4] ;
pos_clk__Seg[5]__delay:		DELAY (POSEDGE) clk Seg[5] ;
pos_clk__Seg[6]__delay:		DELAY (POSEDGE) clk Seg[6] ;
pos_clk__SerOut__delay:		DELAY (POSEDGE) clk SerOut ;
pos_clk__SerOutValid__delay:		DELAY (POSEDGE) clk SerOutValid ;
pos_clk__count_out[0]__delay:		DELAY (POSEDGE) clk count_out[0] ;
pos_clk__count_out[1]__delay:		DELAY (POSEDGE) clk count_out[1] ;
pos_clk__count_out[2]__delay:		DELAY (POSEDGE) clk count_out[2] ;
pos_clk__count_out[3]__delay:		DELAY (POSEDGE) clk count_out[3] ;
___4.564__delay:		DELAY  4.564 ;

ENDMODEL
